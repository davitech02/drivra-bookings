import { useState } from 'react';
import { useParams } from 'react-router-dom';
import Navbar from '../../components/feature/Navbar';
import Footer from '../../components/feature/Footer';
import ImageGallery from './components/ImageGallery';
import PropertyInfo from './components/PropertyInfo';
import BookingPanel from './components/BookingPanel';
import Reviews from './components/Reviews';
import { propertyDetails } from '../../mocks/property-details';

export default function PropertyDetail() {
  const { id } = useParams();
  const [showGallery, setShowGallery] = useState(false);

  return (
    <div className="min-h-screen bg-[#F7F7F7]" style={{ fontFamily: 'DM Sans, sans-serif' }}>
      <Navbar />

      <div className="pt-24 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="mb-6">
            <h1
              className="text-3xl md:text-4xl font-bold text-[#222222] mb-3"
              style={{ fontFamily: 'Playfair Display, serif' }}
            >
              {propertyDetails.title}
            </h1>
            <div className="flex flex-wrap items-center gap-4 text-sm">
              <div className="flex items-center gap-1">
                <i className="ri-star-fill text-[#FF385C]"></i>
                <span className="font-semibold text-[#222222]">{propertyDetails.rating}</span>
                <span className="text-[#717171]">({propertyDetails.reviews} reviews)</span>
              </div>
              <span className="text-[#717171]">•</span>
              <div className="flex items-center gap-1 text-[#717171]">
                <i className="ri-map-pin-line"></i>
                <span>{propertyDetails.location}</span>
              </div>
            </div>
          </div>

          {/* Image Gallery */}
          <ImageGallery
            images={propertyDetails.images}
            onViewAll={() => setShowGallery(true)}
          />

          {/* Main Content */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mt-8">
            <div className="lg:col-span-2">
              <PropertyInfo property={propertyDetails} />
              <Reviews />
            </div>

            <div className="lg:col-span-1">
              <BookingPanel property={propertyDetails} />
            </div>
          </div>
        </div>
      </div>

      {showGallery && (
        <div className="fixed inset-0 bg-black z-50 flex items-center justify-center">
          <button
            onClick={() => setShowGallery(false)}
            className="absolute top-6 right-6 w-12 h-12 flex items-center justify-center bg-white/10 backdrop-blur-sm rounded-full hover:bg-white/20 transition-all cursor-pointer z-10"
          >
            <i className="ri-close-line text-2xl text-white"></i>
          </button>
          <div className="max-w-6xl w-full px-4">
            <div className="grid grid-cols-1 gap-4 max-h-screen overflow-y-auto py-20">
              {propertyDetails.images.map((image, index) => (
                <img
                  key={index}
                  src={image}
                  alt={`Gallery ${index + 1}`}
                  className="w-full rounded-2xl"
                />
              ))}
            </div>
          </div>
        </div>
      )}

      <Footer />
    </div>
  );
}