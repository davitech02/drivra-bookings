from flask import Flask
from flask_cors import CORS
from flask_jwt_extended import JWTManager
from models import db
import os
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)

# Configuration
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL', 'postgresql://localhost/vacation_rental')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['JWT_SECRET_KEY'] = os.getenv('JWT_SECRET_KEY', 'your-secret-key-change-in-production')
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = False

# Initialize extensions
db.init_app(app)
jwt = JWTManager(app)
CORS(app, origins=['http://localhost:5173', 'http://localhost:3000'])

# Register blueprints
from routes.auth import auth_bp
from routes.properties import properties_bp
from routes.bookings import bookings_bp
from routes.payments import payments_bp
from routes.admin import admin_bp
from routes.analytics import analytics_bp

app.register_blueprint(auth_bp, url_prefix='/api/auth')
app.register_blueprint(properties_bp, url_prefix='/api/properties')
app.register_blueprint(bookings_bp, url_prefix='/api/bookings')
app.register_blueprint(payments_bp, url_prefix='/api/payments')
app.register_blueprint(admin_bp, url_prefix='/api/admin')
app.register_blueprint(analytics_bp, url_prefix='/api/analytics')

# Create tables
with app.app_context():
    # Create all tables
    db.create_all()
    
    # Create page_visits table if not exists
    from sqlalchemy import text
    try:
        db.session.execute(text("""
            CREATE TABLE IF NOT EXISTS page_visits (
                id SERIAL PRIMARY KEY,
                ip_address VARCHAR(50),
                user_agent TEXT,
                page_url VARCHAR(500),
                visited_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """))
        db.session.commit()
    except Exception as e:
        print(f"Error creating page_visits table: {e}")
        db.session.rollback()

@app.route('/api/health', methods=['GET'])
def health_check():
    return {'status': 'ok', 'message': 'Backend is running'}, 200

if __name__ == '__main__':
    app.run(debug=True, port=5000)