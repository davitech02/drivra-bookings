from flask import Blueprint, request, jsonify, redirect
from flask_jwt_extended import jwt_required, get_jwt_identity
from models import db, Booking, User, Property
from notifications import send_booking_notifications
import requests
import os
import secrets
from datetime import datetime

payments_bp = Blueprint('payments', __name__)

FLUTTERWAVE_BASE_URL = 'https://api.flutterwave.com/v3'
FLUTTERWAVE_SECRET_KEY = os.getenv('FLUTTERWAVE_SECRET_KEY')
FLUTTERWAVE_PUBLIC_KEY = os.getenv('FLUTTERWAVE_PUBLIC_KEY')
FRONTEND_URL = os.getenv('FRONTEND_URL', 'http://localhost:5173')

@payments_bp.route('/initiate', methods=['POST'])
def initiate_payment():
    """Initiate Flutterwave payment for a booking"""
    try:
        data = request.get_json()
        booking_id = data.get('booking_id')
        customer_name = data.get('customer_name')
        customer_email = data.get('customer_email')
        customer_phone = data.get('customer_phone')
        
        booking = Booking.query.get(booking_id)
        if not booking:
            return jsonify({'error': 'Booking not found'}), 404
        
        tx_ref = f"TXN-{booking.booking_ref}-{secrets.token_hex(4).upper()}"
        
        payload = {
            "tx_ref": tx_ref,
            "amount": booking.total_price,
            "currency": "USD",
            "redirect_url": f"{FRONTEND_URL}/api/payments/callback",
            "payment_options": "card,banktransfer,ussd",
            "customer": {
                "email": customer_email,
                "phonenumber": customer_phone,
                "name": customer_name
            },
            "customizations": {
                "title": "Drivra Bookings",
                "description": f"Payment for booking {booking.booking_ref}",
                "logo": f"{FRONTEND_URL}/logo.png"
            },
            "meta": {
                "booking_id": booking_id,
                "booking_ref": booking.booking_ref
            }
        }
        
        headers = {
            'Authorization': f'Bearer {FLUTTERWAVE_SECRET_KEY}',
            'Content-Type': 'application/json'
        }
        
        response = requests.post(
            f'{FLUTTERWAVE_BASE_URL}/payments',
            json=payload,
            headers=headers
        )
        
        if response.status_code == 200:
            result = response.json()
            if result.get('status') == 'success':
                payment_link = result['data']['link']
                booking.payment_link_token = tx_ref
                db.session.commit()
                
                return jsonify({
                    'success': True,
                    'payment_url': payment_link,
                    'tx_ref': tx_ref
                }), 200
            else:
                return jsonify({'error': 'Failed to create payment link'}), 400
        else:
            return jsonify({'error': 'Payment gateway error'}), 500
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@payments_bp.route('/verify', methods=['POST'])
def verify_payment():
    """Verify Flutterwave payment transaction"""
    try:
        data = request.get_json()
        transaction_id = data.get('transaction_id')
        
        if not transaction_id:
            return jsonify({'error': 'Transaction ID required'}), 400
        
        headers = {
            'Authorization': f'Bearer {FLUTTERWAVE_SECRET_KEY}',
            'Content-Type': 'application/json'
        }
        
        response = requests.get(
            f'{FLUTTERWAVE_BASE_URL}/transactions/{transaction_id}/verify',
            headers=headers
        )
        
        if response.status_code == 200:
            result = response.json()
            
            if result.get('status') == 'success':
                transaction_data = result['data']
                
                if transaction_data['status'] == 'successful':
                    booking_id = transaction_data.get('meta', {}).get('booking_id')
                    
                    if booking_id:
                        booking = Booking.query.get(booking_id)
                        if booking:
                            booking.status = 'confirmed'
                            db.session.commit()

                            # ── Send email + SMS confirmation ──
                            try:
                                notif_result = send_booking_notifications(booking)
                                print(f"[Notifications] Result: {notif_result}")
                            except Exception as notif_err:
                                print(f"[Notifications] Error: {notif_err}")
                            
                            return jsonify({
                                'success': True,
                                'status': 'successful',
                                'booking_id': booking_id,
                                'amount': transaction_data['amount'],
                                'currency': transaction_data['currency']
                            }), 200
                else:
                    booking_id = transaction_data.get('meta', {}).get('booking_id')
                    if booking_id:
                        booking = Booking.query.get(booking_id)
                        if booking:
                            booking.status = 'cancelled'
                            db.session.commit()
                    
                    return jsonify({
                        'success': False,
                        'status': 'failed',
                        'message': 'Payment was not successful'
                    }), 400
            else:
                return jsonify({'error': 'Verification failed'}), 400
        else:
            return jsonify({'error': 'Unable to verify payment'}), 500
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@payments_bp.route('/generate-link', methods=['POST'])
@jwt_required()
def generate_payment_link():
    """Admin generates a shareable payment link for a booking"""
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user or user.role != 'admin':
            return jsonify({'error': 'Admin access required'}), 403
        
        data = request.get_json()
        booking_id = data.get('booking_id')
        
        booking = Booking.query.get(booking_id)
        if not booking:
            return jsonify({'error': 'Booking not found'}), 404
        
        if not booking.payment_link_token:
            booking.payment_link_token = secrets.token_urlsafe(32)
            db.session.commit()
        
        payment_link = f"{FRONTEND_URL}/checkout/{booking_id}?token={booking.payment_link_token}"
        
        return jsonify({
            'success': True,
            'payment_link': payment_link,
            'booking_ref': booking.booking_ref
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@payments_bp.route('/callback', methods=['GET'])
def payment_callback():
    """Handle Flutterwave payment callback redirect"""
    try:
        transaction_id = request.args.get('transaction_id')
        
        if not transaction_id:
            return redirect(f'{FRONTEND_URL}/checkout/payment-failed/unknown')
        
        headers = {
            'Authorization': f'Bearer {FLUTTERWAVE_SECRET_KEY}',
            'Content-Type': 'application/json'
        }
        
        response = requests.get(
            f'{FLUTTERWAVE_BASE_URL}/transactions/{transaction_id}/verify',
            headers=headers
        )
        
        if response.status_code == 200:
            result = response.json()
            
            if result.get('status') == 'success':
                transaction_data = result['data']
                booking_id = transaction_data.get('meta', {}).get('booking_id')
                
                if transaction_data['status'] == 'successful' and booking_id:
                    booking = Booking.query.get(booking_id)
                    if booking:
                        booking.status = 'confirmed'
                        db.session.commit()

                        # ── Send email + SMS confirmation ──
                        try:
                            notif_result = send_booking_notifications(booking)
                            print(f"[Notifications] Result: {notif_result}")
                        except Exception as notif_err:
                            print(f"[Notifications] Error: {notif_err}")
                    
                    return redirect(f'{FRONTEND_URL}/checkout/confirmation/{booking_id}')
                else:
                    if booking_id:
                        booking = Booking.query.get(booking_id)
                        if booking:
                            booking.status = 'cancelled'
                            db.session.commit()
                    
                    return redirect(f'{FRONTEND_URL}/checkout/payment-failed/{booking_id or "unknown"}')
        
        return redirect(f'{FRONTEND_URL}/checkout/payment-failed/unknown')
        
    except Exception as e:
        print(f"Callback error: {str(e)}")
        return redirect(f'{FRONTEND_URL}/checkout/payment-failed/unknown')
